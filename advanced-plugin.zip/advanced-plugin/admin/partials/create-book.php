<?php
  wp_enqueue_media();
?>

<div class="row" style="margin-top: 5px; margin-left: 10px; margin-right: 20px;">
	 <div class="col-md-0"></div>
		<div class="col-sm-12">
	
     <div class="panel panel-primary">
      <div class="panel-heading">
      <h1>Create Book</h1>
      </div>
      <div class="panel-body">
      <div class="col-md-1"></div>
		<div class="col-sm-10"> 
      <form class="form-horizontal" action="javascript:void(0)" id="frm-create-book" method="post">
      	<div class="form-group">
		    <label class="control-label col-sm-2" for="dd_book_shelf">Book Shelf :</label>
		     <div class="col-sm-10">
		    <select class="form-control" id="dd_book_shelf" name="dd_book_shelf">
		    	<option value="">Choose Shelf</option>
		    	<?php 
		    	    if (count($book_shelf) > 0) {
		    	    	foreach ($book_shelf as $key => $value) {
		    	    	?>
		    	    	<option value="<?php echo $value->id;?>"><?php echo ucwords ($value->name)?></option>
		    	    	<?php
		    	    	}
		    	    }

		    	?>
			    </select>
			    </div>
			  </div>
      	 <div class="form-group">
		    <label class="control-label col-sm-2" for="name">Name :</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" id="name" name="name" placeholder="Enter name">
		    </div>
		  </div>

		  <div class="form-group">
		    <label class="control-label col-sm-2" for="email">Email :</label>
		    <div class="col-sm-10">
		      <input type="email" class="form-control" id="email" name="email" placeholder="Enter email">
		    </div>
		  </div>

		  <div class="form-group">
		    <label class="control-label col-sm-2" for="publication">Publication :</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" id="publication" name="publication" placeholder="Enter publication">
		    </div>
		  </div>

		  <div class="form-group">
		    <label class="control-label col-sm-2" for="description">Description :</label>
		    <div class="col-sm-10">
		      <textarea type="text" class="form-control" id="description" name="description" placeholder="Enter description">
		      </textarea>
		    </div>
		  </div>

		  <div class="form-group">
		    <label class="control-label col-sm-2" for="txt_image">Book-image :</label>
		    <div class="col-sm-10">
		      <input type="button" type="button" value="Upload Image" class="form-control" id="txt_image" name="txt_image">
		      <img src="" style="height: 80px;width: 80px;" id="book_image" />
		      <input type="hidden" name="book_cover_image" id="book_cover_image" />
		    </div>
		  </div>
		  

		  <div class="form-group">
		    <label class="control-label col-sm-2" for="amount">Book cost :</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" id="amount" name="amount" placeholder="Enter Book cost">
		    </div>
		  </div>

		  <div class="form-group">
		    <label class="control-label col-sm-2" for="status">Status :</label>
		    <div class="col-sm-10">
		      <select class="form-control" name="status">
		     	<option value="1">Active</option>
		     	<option value="0">Inactive</option>
		     </select>
		    </div>
		  </div>	
				 <div class="form-group">
		    <div class="col-sm-offset-2 col-sm-10">
		      <button type="submit" class="btn btn-primary">Submit</button>
		    </div>
		  </div>
			</form>
	   </div>
    </div>
    </div>
   </div>
</div>