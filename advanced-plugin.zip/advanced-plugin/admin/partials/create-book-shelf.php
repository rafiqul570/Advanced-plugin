<div class="row" style="margin-top: 5px; margin-left: 10px; margin-right: 20px;">
	 <div class="col-md-0"></div>
		<div class="col-sm-12">
	
     <div class="panel panel-primary">
      <div class="panel-heading">
      <h1>Create Book Shelf</h1>
      <button class="btn btn-info pull-right" style="margin-top: -50px;" id="btn-first-ajax">AJAX</button>
      </div>
      <div class="panel-body">
      <div class="col-md-1"></div>
		<div class="col-sm-10">
	
      <form class="form-horizontal" action="javascript:void(0)" id="frm-add-book-shelf" method="post">
      	 <div class="form-group">
		    <label class="control-label col-sm-2" for="name">Name :</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" id="name" name="name" placeholder="Enter name">
		    </div>
		  </div>

		  <div class="form-group">
		    <label class="control-label col-sm-2" for="capacity">Capacity :</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" id="capacity" name="capacity" placeholder="Enter Capacity">
		    </div>
		  </div>

		  <div class="form-group">
		    <label class="control-label col-sm-2" for="location">Location :</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" id="location" name="location" placeholder="Enter Capacity">
		    </div>
		  </div>

		  <div class="form-group">
		    <label class="control-label col-sm-2" for="status">Status :</label>
		    <div class="col-sm-10">
		      <select class="form-control" name="status">
		     	<option value="1">Active</option>
		     	<option value="0">Inactive</option>
		     </select>
		    </div>
		  </div>	
			
			<div class="form-group">
		    <div class="col-sm-offset-2 col-sm-10">
		      <button type="submit" class="btn btn-primary" name="submit">Submit</button>
		    </div>
		  </div>
		</form>
	   </div>
      </div>
    </div>
   </div>
</div>