
<div class="row" style="margin-top: 5px; margin-left: 0px; margin-right: 0px;">
	 <div class="col-md-0"></div>
		<div class="col-sm-12">
	
     <div class="panel panel-primary">
      <div class="panel-heading">
      <h1>Book List</h1>
      </div>
      <div class="panel-body">
      
      <table id="book-list" class="display" style="width:100%">
        <thead>
            <tr>
                <th>Serial</th>
                <th>Name</th>
                <th>Email</th>
                <th>Publication</th>
                <th>Cost</th>
                <th>Image</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            
             if(count($books_data) > 0){
               $i = 0;
                foreach($books_data as $key => $value){ 
               $i++;
               ?>
        
            <tr>
                <td><?php echo $i; ?></td>
                <td><?php echo $value->name; ?></td>
                <td><?php echo $value->email; ?></td>
                <td><?php echo $value->publication; ?></td>
                <td><?php echo $value->amount; ?></td>
                <td>
                <?php 
                 if (!empty($value->book_image)) {
                     
                ?>
                 <img src="<?php echo $value->book_image; ?>" width="50px" height="60px"> 

                 <?php 
                 }else{
                    echo "<i>No Image</i>";
                 } 
                 ?>     
                </td>
                <td>
                  <?php 
                  if($value->status == 1){
                    ?>
                    <button class="btn btn-info">Active</button>
                   <?php
                 }else{
                    ?>
                  <button class="btn btn-danger">Inctive</button>
                  <?php
                }
                ?>
                </td>
                <td>
                  <button class="btn btn-danger btn-delete-book" data-id="<?php echo $value->id; ?>">Delete</button>
                </td>
                
            </tr>
            <?php } } ?>
            </tbody>
        <tfoot>
            <tr>
                <th>Serial</th>
                <th>Name</th>
                <th>Email</th>
                <th>Publication</th>
                <th>Cost</th>
                <th>Image</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </tfoot>
    </table>

      </div>
    </div>
   </div>
</div>