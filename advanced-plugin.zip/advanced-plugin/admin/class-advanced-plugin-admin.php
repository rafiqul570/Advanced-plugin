<?php

class Advanced_Plugin_Admin {

	private $plugin_name;
    
        private $version;
	
	private $table_activator;

	
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-advanced-plugin-activator.php';
	    
	    $activator = new Advanced_Plugin_Activator;
		
		$this->table_activator = $activator;

	}

 //Bootstrap css// 

	public function enqueue_styles() {

       $valid_page = array('book-management','create-book','book-list','create-book-shelf','book-shelf-list');
       $page = isset($_REQUEST['page']) ? $_REQUEST['page'] : '';
       if (in_array($page, $valid_page)) {
      
      //wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/advanced-plugin-admin.css', array(), $this->version, 'all' );
     
           wp_enqueue_style( 'bootstrap', ADVANCED_PLUGIN_BOOK_URL . 'assets/css/bootstrap.css', array(), $this->version, 'all' );

           wp_enqueue_style( 'bootstrap.min', ADVANCED_PLUGIN_BOOK_URL . 'assets/css/bootstrap.min.css', array(), $this->version, 'all' );
		
	   wp_enqueue_style( 'jquery.dataTables.min', ADVANCED_PLUGIN_BOOK_URL . 'assets/css/jquery.dataTables.min.css', array(), $this->version, 'all' );

           wp_enqueue_style( 'sweetalert', ADVANCED_PLUGIN_BOOK_URL . 'assets/css/sweetalert.css', array(), $this->version, 'all' );

       }


	}


//Bootstrap js// 
	public function enqueue_scripts() {
        
       $valid_page = array('book-management','create-book','book-list','create-book-shelf','book-shelf-list');
       $page = isset($_REQUEST['page']) ? $_REQUEST['page'] : '';
       if (in_array($page, $valid_page)) {

       	 wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/advanced-plugin-admin.js', array( 'jquery' ), $this->version, false );
		
		wp_enqueue_script( 'jquery.js',ADVANCED_PLUGIN_BOOK_URL . 'assets/js/jquery-3.6.0.min.js', array( 'jquery' ), $this->version, false );      
		wp_enqueue_script( 'bootstrap.js',ADVANCED_PLUGIN_BOOK_URL . 'assets/js/bootstrap.min.js', array( 'jquery' ), $this->version, false );
		
		wp_enqueue_script( 'jquery.dataTables.min.js',ADVANCED_PLUGIN_BOOK_URL . 'assets/js/jquery.dataTables.min.js', array( 'jquery' ), $this->version, false );
		
		wp_enqueue_script( 'jquery.validate.min',ADVANCED_PLUGIN_BOOK_URL . 'assets/js/jquery.validate.min.js', array( 'jquery' ), $this->version, false );
		
		wp_enqueue_script( 'sweetalert.js',ADVANCED_PLUGIN_BOOK_URL . 'assets/js/sweetalert.js', array( 'jquery' ), $this->version, false );

		wp_localize_script($this->plugin_name, "ad-book", array(
			"ajaxurl" => admin_url("admin-ajax.php"),
			"name" => "msdam",
			"author" =>" Rafiqul Isdlam"

		));

	 }

	}

//Menu Name//	
       public function advanced_menu_section(){
		
		add_menu_page(
			"Crud",
			"Crud",
			"manage_options",
			"crud",
			array($this,"book_management_deshbord")

        );
//Submenu Name//
        add_submenu_page(
        	"crud",
        	"Deshbord",
        	"Deshbord",
        	"manage_options",
        	"crud",
        	array($this,"book_management_deshbord")
        );
//Submenu Name//
        add_submenu_page(
        	"crud",
        	"Add Book",
        	"Add Book",
        	"manage_options",
        	"create-book",
        	array($this,"callback_create_book")
        );
//Submenu Name//
        add_submenu_page(
        	"crud",
        	"Add Book Shelf",
        	"Add Book Shelf",
        	"manage_options",
        	"create-book-shelf",
        	array($this,"callback_create_book_shelf")
        );
//Submenu Name//
        add_submenu_page(
        	"crud",
        	"List Book",
        	"List Book ",
        	"manage_options",
        	"book-list",
        	array($this,"callback_book_list")
        );

        
//Submenu Name//
        add_submenu_page(
        	"crud",
        	"List Book Shelf ",
        	"List Book Shelf ",
        	"manage_options",
        	"book-shelf-list",
        	array($this,"callback_book_shelf_list")
        );
	
	}

//Deshbord page is opened from here   
		    
		    public function book_management_deshbord(){
				echo "<h2>Book Deshbord</h2>";
				
			}


//SELECT QUERY BOOK-SHELF			
			
     public function callback_create_book(){
		global $wpdb;

		$book_shelf = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id,name FROM " . 
				$this->table_activator->Book_Shelf_Prefix(),""
			)

		);
		
		ob_start();
		require_once plugin_dir_path( __FILE__ ) . 'partials/create-book.php';
		    $template = ob_get_contents();
		    ob_end_clean();
		    echo $template;

		}


//SELECT QUERY BOOK-list
			
      public function callback_book_list(){
       	     //echo "<h2>Book List</h2>";

	   global $wpdb;

	   $books_data = $wpdb->get_results(
		$wpdb->prepare(
			"SELECT * FROM " . 
			$this->table_activator->Book_Table_Prefix(),""
		)

	);

	ob_start();
	require_once plugin_dir_path( __FILE__ ) . 'partials/book-list.php';
	    $template = ob_get_contents();
	    ob_end_clean();
	    echo $template;
		}

//List-book-shelf page is opened from here

	public function callback_create_book_shelf(){
		//echo "<h2>Book Shelf</h2>";

	ob_start();
	require_once plugin_dir_path( __FILE__ ) . 'partials/create-book-shelf.php';
		    $template = ob_get_contents();
		    ob_end_clean();
		    echo $template;
			}
//data Select//
		
      public function callback_book_shelf_list(){
		
		global $wpdb;

		$book_shelf = $wpdb->get_results(
			$wpdb->prepare(
			"SELECT * FROM " . 
			$this->table_activator->Book_Shelf_Prefix(),""
		)

		);

		ob_start();
		require_once plugin_dir_path( __FILE__ ) . 'partials/book-shelf-list.php';
		    $template = ob_get_contents();
		    ob_end_clean();
		    echo $template;

		}

//Data Insert//	
			
public function first_ajax_call_admin(){
	global $wpdb;
	$param = isset($_REQUEST['param']) ? $_REQUEST['param'] : '';
	if (!empty($param)) {
		if ($param == 'simple_first_ajax'){
		echo json_encode(array(
			"status" => 1,
			"message" => "first_ajax_call",
			"data" => array(
				"name" => "msam",
				"author" => "Rafiqul Islam"
			)

		));
//Insert book_shelf

	}else if($param == 'create_book_shelf'){
		print_r($_REQUEST);

		$name = isset($_REQUEST['name']) ? $_REQUEST['name'] : '';
		$capacity = isset($_REQUEST['capacity']) ? $_REQUEST['capacity'] : '';
		$location = isset($_REQUEST['location']) ? $_REQUEST['location'] : '';
		$status   = isset($_REQUEST['status']) ? $_REQUEST['status'] : '';

	$wpdb->insert($this->table_activator->Book_Shelf_Prefix(), array(
				"name"     => $name,
				"capacity" => $capacity,
				"location" => $location,
				"status"   => $status
	      ));
		
		if ($wpdb->insert_id > 0) {
			echo json_encode(array(
				"status"  => 1,
				"message" => "Insert Successfully !"
			
			));
		}else{
		     echo json_encode(array(
				"status"  => 0,
				"message" => "Data Not Inserted.",	
			));
		}

//delete_book_shelf

	}elseif($param == "delete_book_shelf"){
		$shelf_id = isset($_REQUEST['shelf_id']) ? $_REQUEST['shelf_id'] : 0;
		 if ($shelf_id > 0) {

		  $wpdb->delete($this->table_activator->Book_Shelf_Prefix(), array(
				
			"id" => $shelf_id,
				
	           ));
				
			echo json_encode(array(
			"status"  => 1,
			"message" => "Delete Successfully !",
			
			));
			
			}else{

				echo json_encode(array(
				"status"  => 0,
				"message" => "Data Not Deleted.",
			));
		
		}

//Insert Book 

   }else if($param == 'create_book'){
	
   	print_r($_REQUEST);
   	$shelf_id = isset($_REQUEST['dd_book_shelf']) ? $_REQUEST['dd_book_shelf'] : '';
	$name = isset($_REQUEST['name']) ? $_REQUEST['name'] : '';
	$email = isset($_REQUEST['email']) ? $_REQUEST['email'] : '';
	$publication = isset($_REQUEST['publication']) ? $_REQUEST['publication'] : '';
	$description = isset($_REQUEST['description']) ? $_REQUEST['description'] : '';
	$book_cover_image = isset($_REQUEST['book_cover_image']) ? $_REQUEST['book_cover_image'] : '';
	$amount = isset($_REQUEST['amount']) ? $_REQUEST['amount'] : '';
	$status = isset($_REQUEST['status']) ? $_REQUEST['status'] : '';
	  
  $wpdb->insert($this->table_activator->Book_Table_Prefix(), array(
		
	"shelf_id"    => $shelf_id,
	"name"        => $name,
	"email"       => $email,
	"publication"    => $publication,
	"description" => $description,
	"book_image"  => $book_cover_image,
	"amount"      => $amount,
	"status"      => $status
    
    ));
	
	if ($wpdb->insert_id > 0) {
		echo json_encode(array(
			"status"  => 1,
			"message" => "Insert Successfully !"
		
		));
	}else{
	     echo json_encode(array(
			"status"  => 0,
			"message" => "Data Not Inserted.",	
		));
	}

//delete_book

    }elseif($param == "delete_book"){
		$book_id = isset($_REQUEST['book_id']) ? $_REQUEST['book_id'] : 0;
		 if ($book_id > 0) {

		  $wpdb->delete($this->table_activator->Book_Table_Prefix(), array(
				
			"id" => $book_id,
				
	           ));
			
			echo json_encode(array(
			"status"  => 1,
			"message" => "Delete Successfully !",
			
		  ));
		
		}else{

			echo json_encode(array(
			"status"  => 0,
			"message" => "Data Not Deleted.",
		));
		
		}
		   
           }

       }

    wp_die();			

   }

			

}




