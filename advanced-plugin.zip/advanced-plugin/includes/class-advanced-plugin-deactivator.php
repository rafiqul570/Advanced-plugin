<?php

class Advanced_Plugin_Deactivator {

	private $table_activator;
	
	public function __construct($activator){
		$this->table_activator = $activator;
	}
	
	public function deactivate() {
		global $wpdb;
		
		$wpdb->query("DROP TABLE IF EXISTS " . $this->table_activator->Book_Table_Prefix());
		
		$wpdb->query("DROP TABLE IF EXISTS " . $this->table_activator->Book_Shelf_Prefix());

//Delete page when plugin deactive//

		$get_data = $wpdb->get_row(

			 $wpdb->prepare("SELECT ID from " .$wpdb->prefix."posts WHERE post_name = %s",'book_tool')

	         );
			
			$page_id = $get_data->ID;
			if ($page_id > 0) {
				wp_delete_post($page_id,true);
			}
		
	
	}




}
