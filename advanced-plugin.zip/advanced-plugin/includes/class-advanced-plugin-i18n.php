<?php

class Advanced_Plugin_i18n {

	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'advanced-plugin',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
