<?php

class Advanced_Plugin {

	protected $loader;

	protected $plugin_name;

	protected $version;

	public function __construct() {
		if ( defined( 'ADVANCED_PLUGIN_VERSION' ) ) {
			$this->version = ADVANCED_PLUGIN_VERSION;
		} else {
			$this->version = '1.0.0';
		}
		$this->plugin_name = 'advanced-plugin';

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();

	}

	private function load_dependencies() {

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-advanced-plugin-loader.php';

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-advanced-plugin-i18n.php';

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-advanced-plugin-admin.php';

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-advanced-plugin-public.php';

		$this->loader = new Advanced_Plugin_Loader();

	}

	private function set_locale() {

		$plugin_i18n = new Advanced_Plugin_i18n();

		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );

	}

	private function define_admin_hooks() {

		$plugin_admin = new Advanced_Plugin_Admin( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
		
		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );

		$this->loader->add_action( 'admin_menu', $plugin_admin, 'advanced_menu_section' );

		$this->loader->add_action( 'wp_ajax_admin_ajax_request', $plugin_admin, 'first_ajax_call_admin' );

	}

	private function define_public_hooks() {

		$plugin_public = new Advanced_Plugin_Public( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );

       //filter for page template
		 $this->loader->add_filter( 'page_template', $plugin_public, 'custom_page_template');
	   
	   //Shortcode hook
		 add_shortcode('render-my-content', array($plugin_public, 'load_book_tool_content'));

       //This is for login page
		// $this->loader->add_action( 'wp_ajax_public_ajax_request', $plugin_public, 'first_ajax_call_public' );


	}

    
    public function run() {
		$this->loader->run();
	}

	public function get_plugin_name() {
		return $this->plugin_name;
	}

	public function get_loader() {
		return $this->loader;
	}

	public function get_version() {
		return $this->version;
	}

}
