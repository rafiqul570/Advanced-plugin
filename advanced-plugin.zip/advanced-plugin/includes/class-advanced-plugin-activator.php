<?php

class Advanced_Plugin_Activator {

//create table//	
	public function activate() {
		$table_query = "CREATE TABLE `".$this->Book_Table_Prefix()."` (
		  `id` int(11) NOT NULL AUTO_INCREMENT,
		  `shelf_id` int(11) DEFAULT NULL,
		  `name` varchar(255) NOT NULL,
		  `email` varchar(255) NOT NULL,
		  `publication` varchar(255) NOT NULL,
		  `description` text NOT NULL,
		  `book_image` varchar(255) NOT NULL,
		  `amount` varchar(255) NOT NULL,
		  `status` int(11) NOT NULL,
		  `create_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
		  PRIMARY KEY (`id`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
				require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta($table_query);
//create table//

		$shelf_query = "CREATE TABLE `".$this->Book_Shelf_Prefix()."` (
		  `id` int(11) NOT NULL AUTO_INCREMENT,
		  `name` varchar(255) NOT NULL,
		  `capacity` varchar(255) NOT NULL,
		  `location` varchar(255) NOT NULL,
		  `status` int(11) NOT NULL,
		  `create_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
		  PRIMARY KEY (`id`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
				require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta($shelf_query);



//create page when plugin active
		if (!empty($get_data)) {
			
		}else{
	//create page
		$post_arr_data = array(
			'post_title'   => 'Book Tool',
			'post_content' =>'Page content of Book tool',
			'post_name'    => 'book_tool',
			'post_status'  => 'publish',
			'post_author'  => 1,
			'post_type'    => 'page',

		);
		    wp_insert_post($post_arr_data);

	}
}
	public function Book_Table_Prefix(){
		global $wpdb;
		return $wpdb->prefix . "book_table";
	}
	
	public function Book_Shelf_Prefix(){
		global $wpdb;
		return $wpdb->prefix . "book_shelf";
	}

	
}
