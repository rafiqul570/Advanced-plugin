<?php
/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://ribd.rf.gd
 * @since             1.0.0
 * @package           Advance_Plugin
 *
 * @wordpress-plugin
 * Plugin Name:       Advanced Plugin
 * Plugin URI:        https://wordpress.org/plugins/advanced-plugin/
 * Description:       This is a short description of what the plugin does. It's displayed in the WordPress admin area.
 * Version:           1.0.0
 * Author:            Rafiqul Islam
 * Author URI:        https://ribd.rf.gd
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       advance-plugin
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

define( 'ADVANCED_PLUGIN_VERSION', '1.0.0' );
define( 'ADVANCED_PLUGIN_BOOK_URL', plugin_dir_url( __FILE__ ));
define( 'ADVANCED_PLUGIN_BOOK_PATH', plugin_dir_url( __FILE__ ));
define( 'BOOKS_MANAGEMENT_TOOL_PLUGIN_PATH', plugin_dir_url( __FILE__ ));



function activate_advanced_plugin() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-advanced-plugin-activator.php';
	$activator = new Advanced_Plugin_Activator;
	$activator->activate();
}

function deactivate_advanced_plugin() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-advanced-plugin-activator.php';
	$activator = new Advanced_Plugin_Activator;

	require_once plugin_dir_path( __FILE__ ) . 'includes/class-advanced-plugin-deactivator.php';
	$deactivator = new Advanced_Plugin_Deactivator($activator);
	$deactivator->deactivate();
}

register_activation_hook( __FILE__, 'activate_advanced_plugin' );
register_deactivation_hook( __FILE__, 'deactivate_advanced_plugin' );

require plugin_dir_path( __FILE__ ) . 'includes/class-advanced-plugin.php';

function run_advanced_plugin() {

	$plugin = new Advanced_Plugin();
	$plugin->run();

}
run_advanced_plugin();
