jQuery(function(){
   jQuery("#example").DataTable();
});