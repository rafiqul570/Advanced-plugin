<?php

class Advanced_Plugin_Public {

	private $plugin_name;

	private $version;
	
	private $table_activator;

	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

		 require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-advanced-plugin-activator.php';
	    
	    $activator = new Advanced_Plugin_Activator;
		
		 $this->table_activator = $activator;


	}

	public function enqueue_styles() {

		//wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/advanced-plugin-public.css', array(), $this->version, 'all' );

		   wp_enqueue_style( 'bootstrap', ADVANCED_PLUGIN_BOOK_URL . 'assets/css/bootstrap.css', array(), $this->version, 'all' );

           wp_enqueue_style( 'bootstrap.min', ADVANCED_PLUGIN_BOOK_URL . 'assets/css/bootstrap.min.css', array(), $this->version, 'all' );
		
	       wp_enqueue_style( 'jquery.dataTables.min', ADVANCED_PLUGIN_BOOK_URL . 'assets/css/jquery.dataTables.min.css', array(), $this->version, 'all' );

           wp_enqueue_style( 'sweetalert', ADVANCED_PLUGIN_BOOK_URL . 'assets/css/sweetalert.css', array(), $this->version, 'all' );

	}

	public function enqueue_scripts() {

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/advanced-plugin-public.js', array( 'jquery' ), $this->version, false );

	    wp_enqueue_script( 'jquery.js',ADVANCED_PLUGIN_BOOK_URL . 'assets/js/jquery-3.6.0.min.js', array( 'jquery' ), $this->version, false );      
		 
		 wp_enqueue_script( 'bootstrap.js',ADVANCED_PLUGIN_BOOK_URL . 'assets/js/bootstrap.min.js', array( 'jquery' ), $this->version, false );
		
		wp_enqueue_script( 'jquery.dataTables.min.js',ADVANCED_PLUGIN_BOOK_URL . 'assets/js/jquery.dataTables.min.js', array( 'jquery' ), $this->version, false );
		
		wp_enqueue_script( 'jquery.validate.min',ADVANCED_PLUGIN_BOOK_URL . 'assets/js/jquery.validate.min.js', array( 'jquery' ), $this->version, false );
		
		wp_enqueue_script( 'sweetalert.js',ADVANCED_PLUGIN_BOOK_URL . 'assets/js/sweetalert.js', array( 'jquery' ), $this->version, false );


		wp_localize_script($this->plugin_name, "ad-book", array(
			"ajaxurl" => admin_url("admin-ajax.php"),
			"name" => "msdam",
			"author" =>" Rafiqul Isdlam"

		));

	 }


	public function custom_page_template(){

		global $post;

		if ($post->post_name == "book_tool") {
			
			$page_template = BOOKS_MANAGEMENT_TOOL_PLUGIN_PATH."public/partials/book-tool-layout.php";

		}
	        return $page_template;
		
	}

	public function load_book_tool_content(){
		       //echo "<h2>Book List Public</h2>";

		   global $wpdb;

		   $books_data = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM " . 
				$this->table_activator->Book_Table_Prefix(),""
			)

		    );
		 
			ob_start();
			
			require_once plugin_dir_path( __FILE__ ) . 'partials/tmpl-book-tool-content.php';
		    $template = ob_get_contents();
		    
		    ob_end_clean();
		    
		    echo $template;
		
		}


}
