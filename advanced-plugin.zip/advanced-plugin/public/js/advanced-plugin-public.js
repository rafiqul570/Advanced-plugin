jQuery(function(){
//Datatable code//	
    jQuery('#book-list').DataTable();
    
    jQuery('#book-shelf-list').DataTable();

    
//Processing event on button click//
     jQuery(document).on("click","#btn-first-ajax",function(){
        
        var postdata = "action=admin_ajax_request&param=simple_first_ajax";
        
        jQuery.post(ajaxurl,postdata, function(response){
        
            var data = jQuery.parseJSON(response);
            //console.log(response)

         });

     });

});
