<?php

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( '<?php get_header(); ?>




 <?php do_shortcode("[render-my-content]"); ?>



<?php get_footer();?>' );

    
}
?>

